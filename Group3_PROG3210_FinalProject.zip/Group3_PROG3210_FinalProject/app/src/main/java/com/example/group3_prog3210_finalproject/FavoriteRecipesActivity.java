package com.example.group3_prog3210_finalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.group3_prog3210_finalproject.database.DbHandler;
import com.example.group3_prog3210_finalproject.models.RecipeModel;

import java.util.ArrayList;

public class FavoriteRecipesActivity extends AppCompatActivity {

    private ArrayList<RecipeModel> recipeModelArrayList;
    private DbHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorite_recipes);

        recipeModelArrayList = new ArrayList<>();
        dbHandler = new DbHandler(FavoriteRecipesActivity.this);
    }

    @Override
    protected void onStart() {
        super.onStart();

        recipeModelArrayList = dbHandler.readFavoriteRecipes();
        RecipeRVAdaptor recipeRVAdaptor = new RecipeRVAdaptor(recipeModelArrayList, FavoriteRecipesActivity.this);
        RecyclerView recipesRV = findViewById(R.id.recyclerFavouriteRecipes);
        LinearLayoutManager linearLayoutManager =
                new LinearLayoutManager(FavoriteRecipesActivity.this, RecyclerView.VERTICAL, false);
        recipesRV.setLayoutManager(linearLayoutManager);
        recipesRV.setAdapter(recipeRVAdaptor);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}