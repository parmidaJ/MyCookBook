package com.example.group3_prog3210_finalproject;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.group3_prog3210_finalproject.database.DbHandler;
import com.example.group3_prog3210_finalproject.models.RecipeModel;

public class AddRecipeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_recipe);

        EditText recipeNameEdt = findViewById(R.id.idRecipeName);
        EditText recipeIngredientsEdt = findViewById(R.id.idRecipeIngredients);
        EditText peopleServedEdt = findViewById(R.id.idPeopleServed);
        EditText cookingTimeEdt = findViewById(R.id.idCookingTime);
        EditText instructionsEdt = findViewById(R.id.idInstructions);
        Button addRecipeBtn = findViewById(R.id.idBtnAddRecipe);

        DbHandler dbHandler = new DbHandler(AddRecipeActivity.this);

        addRecipeBtn.setOnClickListener(v -> {

            String recipeName = recipeNameEdt.getText().toString();
            String recipeIngredients = recipeIngredientsEdt.getText().toString();
            int peopleServed = 0;
            int cookingTime = 0;
            String instructions = instructionsEdt.getText().toString();
            boolean isFavorite = false;

            if (recipeName.isEmpty() || recipeIngredients.isEmpty() || instructions.isEmpty()) {
                Toast.makeText(AddRecipeActivity.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                peopleServed = Integer.parseInt(peopleServedEdt.getText().toString());
            } catch (NumberFormatException e) {
                Toast.makeText(AddRecipeActivity.this, "Please enter a valid number for people served.", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                cookingTime = Integer.parseInt(cookingTimeEdt.getText().toString());
            } catch (NumberFormatException e) {
                Toast.makeText(AddRecipeActivity.this, "Please enter a valid number for cooking time.", Toast.LENGTH_SHORT).show();
                return;
            }

            RecipeModel recipe = new RecipeModel(recipeName, recipeIngredients, instructions, cookingTime, peopleServed, isFavorite);
            dbHandler.addNewRecipe(recipe);

            finish();
        });

    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}