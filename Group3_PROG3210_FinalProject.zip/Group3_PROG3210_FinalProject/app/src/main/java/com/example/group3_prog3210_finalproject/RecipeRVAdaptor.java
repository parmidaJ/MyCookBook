package com.example.group3_prog3210_finalproject;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.group3_prog3210_finalproject.database.DbHandler;
import com.example.group3_prog3210_finalproject.models.RecipeModel;

import java.util.ArrayList;

public class RecipeRVAdaptor extends RecyclerView.Adapter<RecipeRVAdaptor.ViewHolder> {

    private final ArrayList<RecipeModel> recipeModelArrayList;
    private final Context context;

    public RecipeRVAdaptor(ArrayList<RecipeModel> recipeModelArrayList, Context context) {
        this.recipeModelArrayList = recipeModelArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recipe_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        RecipeModel model = recipeModelArrayList.get(position);

        holder.recipeNameTV.setText(model.getName());
        holder.favoriteIconIV.setImageResource(
                model.isFavorite() ?
                        R.drawable.ic_baseline_favorite_24 :
                        R.drawable.ic_outline_favorite_border_24
        );

        holder.itemView.setOnClickListener(
                v -> {
                    Intent intent = new Intent(context, RecipeDetailActivity.class);
                    intent.putExtra("id", model.getId());
                    intent.putExtra("name", model.getName());
                    intent.putExtra("ingredients", model.getIngredientsInstructions());
                    intent.putExtra("cookingInstructions", model.getCookingInstructions());
                    intent.putExtra("peopleServed", model.getPeopleServed());
                    intent.putExtra("cookingTime", model.getCookingTime());
                    intent.putExtra("isFavorite", model.isFavorite());
                    context.startActivity(intent);
                }
        );

        holder.favoriteIconIV.setOnClickListener(
                view -> {
                    model.setFavorite(!model.isFavorite());

                    DbHandler dbHandler = new DbHandler(view.getContext());
                    dbHandler.updateRecipe(model);

                    ((ImageView) view).setImageResource(
                            model.isFavorite() ?
                                    R.drawable.ic_baseline_favorite_24 :
                                    R.drawable.ic_outline_favorite_border_24
                    );
                }
        );
    }

    @Override
    public int getItemCount() {
        return recipeModelArrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView recipeNameTV;
        private final ImageView favoriteIconIV;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            recipeNameTV = itemView.findViewById(R.id.idRecipeName);
            favoriteIconIV = itemView.findViewById(R.id.imageViewFavoriteIcon);
        }
    }
}
