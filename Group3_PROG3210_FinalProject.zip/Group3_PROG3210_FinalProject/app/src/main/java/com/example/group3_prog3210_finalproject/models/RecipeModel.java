package com.example.group3_prog3210_finalproject.models;

public class RecipeModel {
    private int id;
    private String name;
    private String ingredientsInstructions;
    private String cookingInstructions;
    private int peopleServed;
    private int cookingTime;
    private boolean isFavorite;

    public RecipeModel(int id,
                       String name,
                       String ingredientsInstructions,
                       String cookingInstructions,
                       int peopleServed,
                       int cookingTime,
                       boolean isFavorite) {
        this.id = id;
        this.name = name;
        this.ingredientsInstructions = ingredientsInstructions;
        this.cookingInstructions = cookingInstructions;
        this.peopleServed = peopleServed;
        this.cookingTime = cookingTime;
        this.isFavorite = isFavorite;
    }

    public RecipeModel(int id,
                       String name,
                       String ingredientsInstructions,
                       String cookingInstructions,
                       int peopleServed,
                       int cookingTime,
                       int isFavorite) {
        this.id = id;
        this.name = name;
        this.ingredientsInstructions = ingredientsInstructions;
        this.cookingInstructions = cookingInstructions;
        this.peopleServed = peopleServed;
        this.cookingTime = cookingTime;
        this.isFavorite = isFavorite == 1;
    }

    public RecipeModel(String name,
                       String ingredientsInstructions,
                       String cookingInstructions,
                       int peopleServed,
                       int cookingTime,
                       boolean isFavorite) {
        this.name = name;
        this.ingredientsInstructions = ingredientsInstructions;
        this.cookingInstructions = cookingInstructions;
        this.peopleServed = peopleServed;
        this.cookingTime = cookingTime;
        this.isFavorite = isFavorite;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIngredientsInstructions() {
        return ingredientsInstructions;
    }

    public void setIngredientsInstructions(String ingredientsInstructions) {
        this.ingredientsInstructions = ingredientsInstructions;
    }

    public String getCookingInstructions() {
        return cookingInstructions;
    }

    public void setCookingInstructions(String cookingInstructions) {
        this.cookingInstructions = cookingInstructions;
    }

    public int getPeopleServed() {
        return peopleServed;
    }

    public void setPeopleServed(int peopleServed) {
        this.peopleServed = peopleServed;
    }

    public int getCookingTime() {
        return cookingTime;
    }

    public void setCookingTime(int cookingTime) {
        this.cookingTime = cookingTime;
    }

    public boolean isFavorite() {
        return isFavorite;
    }

    public void setFavorite(boolean favorite) {
        isFavorite = favorite;
    }
}
