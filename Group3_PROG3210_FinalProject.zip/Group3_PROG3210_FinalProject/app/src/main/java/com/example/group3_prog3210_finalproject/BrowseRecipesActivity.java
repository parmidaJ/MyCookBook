package com.example.group3_prog3210_finalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.example.group3_prog3210_finalproject.database.DbHandler;
import com.example.group3_prog3210_finalproject.models.RecipeModel;

import java.util.ArrayList;

public class BrowseRecipesActivity extends AppCompatActivity {

    private ArrayList<RecipeModel> recipeModelArrayList;
    private DbHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browse_recipes);

        recipeModelArrayList = new ArrayList<>();
        dbHandler = new DbHandler(BrowseRecipesActivity.this);

        findViewById(R.id.buttonAddRecipe).setOnClickListener(
                v -> startActivity(new Intent(this, AddRecipeActivity.class))
        );

        findViewById(R.id.buttonViewFavorite).setOnClickListener(
                v -> startActivity(new Intent(this, FavoriteRecipesActivity.class))
        );

        findViewById(R.id.imageViewSearchIcon).setOnClickListener(this::performSearch);
    }

    @Override
    protected void onStart() {
        super.onStart();

        recipeModelArrayList = dbHandler.readRecipes();

        RecyclerView recipesRV = findViewById(R.id.recyclerViewRecipes);
        recipesRV.setLayoutManager(
                new LinearLayoutManager(BrowseRecipesActivity.this, RecyclerView.VERTICAL, false)
        );
        recipesRV.setAdapter(
                new RecipeRVAdaptor(recipeModelArrayList, BrowseRecipesActivity.this)
        );
    }

    private void performSearch(View view) {
        EditText searchInput = findViewById(R.id.editTextSearch);
        String searchText = searchInput.getText().toString();

        recipeModelArrayList = dbHandler.searchRecipes(searchText);

        RecyclerView recipesRV = findViewById(R.id.recyclerViewRecipes);
        recipesRV.setLayoutManager(
                new LinearLayoutManager(BrowseRecipesActivity.this, RecyclerView.VERTICAL, false)
        );
        recipesRV.setAdapter(
                new RecipeRVAdaptor(recipeModelArrayList, BrowseRecipesActivity.this)
        );
    }
}