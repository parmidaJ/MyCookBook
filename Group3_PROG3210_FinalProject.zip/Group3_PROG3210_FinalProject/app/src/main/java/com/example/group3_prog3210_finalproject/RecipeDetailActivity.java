package com.example.group3_prog3210_finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.group3_prog3210_finalproject.database.DbHandler;
import com.example.group3_prog3210_finalproject.models.RecipeModel;

public class RecipeDetailActivity extends AppCompatActivity {

    private RecipeModel recipeModel;
    private DbHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_detail);

        dbHandler = new DbHandler(this);

        findViewById(R.id.likeIconButton).setOnClickListener(
                view -> {
                    recipeModel.setFavorite(!recipeModel.isFavorite());

                    DbHandler dbHandler = new DbHandler(view.getContext());
                    dbHandler.updateRecipe(recipeModel);

                    ((ImageView) view).setImageResource(
                            recipeModel.isFavorite() ?
                                    R.drawable.ic_baseline_favorite_24 :
                                    R.drawable.ic_outline_favorite_border_24
                    );
                }
        );

        findViewById(R.id.buttonDeleteRecipe).setOnClickListener(
                view -> {
                    dbHandler.deleteRecipe(recipeModel.getId());
                    finish();
                }
        );

        findViewById(R.id.buttonEditRecipe).setOnClickListener(
                view -> {
                    Intent editIntent = new Intent(view.getContext(), UpdateRecipeActivity.class);
                    editIntent.putExtra("id", recipeModel.getId());
                    startActivity(editIntent);
                }
        );
    }

    @Override
    protected void onStart() {
        super.onStart();

        recipeModel = dbHandler.readRecipe(getIntent().getIntExtra("id", -1));

        ((ImageView) findViewById(R.id.likeIconButton)).setImageResource(
                recipeModel.isFavorite() ?
                        R.drawable.ic_baseline_favorite_24 :
                        R.drawable.ic_outline_favorite_border_24
        );
        ((TextView) findViewById(R.id.foodNameTxt)).setText(recipeModel.getName());
        ((TextView) findViewById(R.id.ingredientsTxt)).setText(recipeModel.getIngredientsInstructions());
        ((TextView) findViewById(R.id.recipeTxt)).setText(recipeModel.getCookingInstructions());
        ((TextView) findViewById(R.id.personTxt)).setText(
                String.format("Serves %s", recipeModel.getPeopleServed())
        );
        ((TextView) findViewById(R.id.timeTxt)).setText(
                String.format("%s min", recipeModel.getCookingTime())
        );
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}