package com.example.group3_prog3210_finalproject.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.NonNull;

import com.example.group3_prog3210_finalproject.models.RecipeModel;

import java.util.ArrayList;

public class DbHandler extends SQLiteOpenHelper {

    private static final String DB_NAME = "recipesDB";
    private static final int DB_VERSION = 2;

    private static final String TABLE_NAME = "recipe";
    private static final String ID_COL = "id";
    private static final String NAME_COL = "name";
    private static final String INGREDIENTS_COL = "ingredients";
    private static final String INSTRUCTIONS_COL = "instructions";
    private static final String COOKING_TIME_COL = "cooking_time";
    private static final String PEOPLE_SERVED_COL = "people_served";
    private static final String IS_FAVORITE_COL = "is_favorite";

    public DbHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }


    @Override
    public void onCreate(@NonNull SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + NAME_COL + " TEXT, "
                + INGREDIENTS_COL + " TEXT, "
                + INSTRUCTIONS_COL + " TEXT, "
                + COOKING_TIME_COL + " INTEGER, "
                + PEOPLE_SERVED_COL + " INTEGER, "
                + IS_FAVORITE_COL + " INTEGER "
                + ");";

        db.execSQL(query);

        // Add some default recipes
        ContentValues values;
        RecipeModel model;

        model = new RecipeModel(
                "Stuffed Green Peppers",
                "6 green bell peppers\n" +
                        "1 pound ground beef\n" +
                        "⅓ cup chopped onion\n" +
                        "salt and pepper to taste\n" +
                        "1 (14.5 ounces) can of whole peeled tomatoes, chopped\n" +
                        "½ cup uncooked rice\n" +
                        "1 teaspoon Worcestershire sauce\n" +
                        "1 cup shredded Cheddar cheese\n" +
                        "2 (10.75 ounces) cans of condensed tomato soup",
                "-Bring a large pot of salted water to a boil. Cut the tops off bell peppers and remove the seeds. Cook bell peppers in boiling water for 5 minutes; drain. Sprinkle salt inside each bell pepper and set aside.\n" +
                        "-Place ground beef and onion in a large skillet over medium heat; cook and stir until beef is browned, about 5 minutes. Drain off excess fat and season with salt and pepper. Stir in tomatoes, 1/2 cup water, rice, and Worcestershire sauce; reduce heat to low, cover, and simmer until rice is tender, about 15 minutes. Remove from heat and stir in cheese.\n" +
                        "-Preheat the oven to 350 degrees F (175 degrees C).\n" +
                        "-Stuff each bell pepper with beef and rice mixture; arrange open-side up in a baking dish.\n" +
                        "-Combine tomato soup with just enough water in a medium bowl to make the soup a gravy consistency; pour over the bell peppers and cover with aluminum foil.\n" +
                        "-Bake in the preheated oven until heated through and cheese is melted and bubbly, about 25 to 30 minutes.",
                6,
                60,
                false
        );
        values = new ContentValues();
        values.put(NAME_COL, model.getName());
        values.put(INGREDIENTS_COL, model.getIngredientsInstructions());
        values.put(INSTRUCTIONS_COL, model.getCookingInstructions());
        values.put(COOKING_TIME_COL, model.getCookingTime());
        values.put(PEOPLE_SERVED_COL, model.getPeopleServed());
        values.put(IS_FAVORITE_COL, model.isFavorite() ? 1 : 0);
        db.insert(TABLE_NAME, null, values);

        model = new RecipeModel(
                "Broccoli and Chicken Stir-Fry",
                "⅔ cup soy sauce\n" +
                        "¼ cup brown sugar\n" +
                        "½ teaspoon ground ginger\n" +
                        "1 pinch red pepper flakes, or to taste\n" +
                        "2 tablespoons cornstarch\n" +
                        "2 teaspoons vegetable oil, or to taste\n" +
                        "3 skinless, boneless chicken breast halves, cut into chunks\n" +
                        "1 onion, sliced\n" +
                        "3 cups broccoli florets",
                "-All gathered ingredients.\n" +
                        "-Stir soy sauce, brown sugar, ginger, and red pepper flakes together in a bowl until sugar dissolves. Mix water and cornstarch together in a small bowl; stir with a whisk until cornstarch dissolves completely.\n" +
                        "-Heat oil in a large skillet over high heat. Fry chicken and onion in hot oil until chicken is no longer pink in the center and onion is tender, 5 to 7 minutes.\n" +
                        "-Stir in broccoli with chicken and onion; sauté until broccoli is hot, about 5 minutes.\n" +
                        "-Push chicken and vegetable mixture to the side of the skillet. Pour soy sauce mixture into the vacant part of the skillet. Stir cornstarch slurry into soy sauce mixture until the color is consistent.\n" +
                        "-Move chicken and vegetables back into the center of the pan; sauté until sauce thickens and coats chicken and vegetables, about 5 minutes more.",
                3,
                35,
                false
        );
        values = new ContentValues();
        values.put(NAME_COL, model.getName());
        values.put(INGREDIENTS_COL, model.getIngredientsInstructions());
        values.put(INSTRUCTIONS_COL, model.getCookingInstructions());
        values.put(COOKING_TIME_COL, model.getCookingTime());
        values.put(PEOPLE_SERVED_COL, model.getPeopleServed());
        values.put(IS_FAVORITE_COL, model.isFavorite() ? 1 : 0);
        db.insert(TABLE_NAME, null, values);

        model = new RecipeModel(
                "Turkey à la King",
                "2 tablespoons butter\n" +
                        "3 fresh mushrooms, sliced\n" +
                        "1 tablespoon all-purpose flour\n" +
                        "1 cup chicken broth\n" +
                        "1 cup chopped cooked turkey\n" +
                        "½ cup heavy cream\n" +
                        "⅓ cup frozen peas, thawed\n" +
                        "salt and pepper to taste",
                "-Cook and stir butter in a large skillet over medium-low heat until golden brown.\n" +
                        "-Add mushrooms to the skillet and cook in browned butter, stirring occasionally, until tender. Stir in flour until smooth. Slowly whisk in chicken broth; cook until slightly thickened.\n" +
                        "-Stir in turkey, cream, and peas. Reduce heat to low; cook until thickened. Season with salt and pepper.",
                4,
                25,
                false
        );
        values = new ContentValues();
        values.put(NAME_COL, model.getName());
        values.put(INGREDIENTS_COL, model.getIngredientsInstructions());
        values.put(INSTRUCTIONS_COL, model.getCookingInstructions());
        values.put(COOKING_TIME_COL, model.getCookingTime());
        values.put(PEOPLE_SERVED_COL, model.getPeopleServed());
        values.put(IS_FAVORITE_COL, model.isFavorite() ? 1 : 0);
        db.insert(TABLE_NAME, null, values);
    }

    @Override
    public void onUpgrade(@NonNull SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public void addNewRecipe(@NonNull RecipeModel model) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(NAME_COL, model.getName());
        values.put(INGREDIENTS_COL, model.getIngredientsInstructions());
        values.put(INSTRUCTIONS_COL, model.getCookingInstructions());
        values.put(COOKING_TIME_COL, model.getCookingTime());
        values.put(PEOPLE_SERVED_COL, model.getPeopleServed());
        values.put(IS_FAVORITE_COL, model.isFavorite() ? 1 : 0);

        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    public ArrayList<RecipeModel> readRecipes() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursorCourses = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

        ArrayList<RecipeModel> resultsArrayList = new ArrayList<>();

        if (cursorCourses.moveToFirst()) {
            do {
                resultsArrayList.add(new RecipeModel(
                        cursorCourses.getInt(0),
                        cursorCourses.getString(1),
                        cursorCourses.getString(2),
                        cursorCourses.getString(3),
                        cursorCourses.getInt(5),
                        cursorCourses.getInt(4),
                        cursorCourses.getInt(6)));
            } while (cursorCourses.moveToNext());
        }

        cursorCourses.close();
        return resultsArrayList;
    }

    public ArrayList<RecipeModel> readFavoriteRecipes() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursorCourses = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " + IS_FAVORITE_COL + "=?;",
                new String[]{"1"});

        ArrayList<RecipeModel> resultsArrayList = new ArrayList<>();

        if (cursorCourses.moveToFirst()) {
            do {
                resultsArrayList.add(new RecipeModel(
                        cursorCourses.getInt(0),
                        cursorCourses.getString(1),
                        cursorCourses.getString(2),
                        cursorCourses.getString(3),
                        cursorCourses.getInt(5),
                        cursorCourses.getInt(4),
                        cursorCourses.getInt(6)));
            } while (cursorCourses.moveToNext());
        }

        cursorCourses.close();
        return resultsArrayList;
    }

    public RecipeModel readRecipe(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursorCourses = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE id=?;",
                new String[]{Integer.toString(id)});

        ArrayList<RecipeModel> resultsArrayList = new ArrayList<>();

        if (cursorCourses.moveToFirst()) {
            do {
                resultsArrayList.add(new RecipeModel(
                        cursorCourses.getInt(0),
                        cursorCourses.getString(1),
                        cursorCourses.getString(2),
                        cursorCourses.getString(3),
                        cursorCourses.getInt(5),
                        cursorCourses.getInt(4),
                        cursorCourses.getInt(6)));
            } while (cursorCourses.moveToNext());
        }

        cursorCourses.close();
        return resultsArrayList.get(0);
    }

    public void updateRecipe(RecipeModel model) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(NAME_COL, model.getName());
        values.put(INGREDIENTS_COL, model.getIngredientsInstructions());
        values.put(INSTRUCTIONS_COL, model.getCookingInstructions());
        values.put(COOKING_TIME_COL, model.getCookingTime());
        values.put(PEOPLE_SERVED_COL, model.getPeopleServed());
        values.put(IS_FAVORITE_COL, model.isFavorite() ? 1 : 0);

        db.update(TABLE_NAME, values, "id=?", new String[]{Integer.toString(model.getId())});
        db.close();
    }

    public void deleteRecipe(int recipeId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, "id=?", new String[]{Integer.toString(recipeId)});
        db.close();
    }


    public ArrayList<RecipeModel> searchRecipes(String searchPhrase) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursorCourses = db.rawQuery(
                "SELECT * FROM " + TABLE_NAME + " WHERE " + NAME_COL + " LIKE '%" + searchPhrase + "%';",
                null);

        ArrayList<RecipeModel> resultsArrayList = new ArrayList<>();

        if (cursorCourses.moveToFirst()) {
            do {
                resultsArrayList.add(new RecipeModel(
                        cursorCourses.getInt(0),
                        cursorCourses.getString(1),
                        cursorCourses.getString(2),
                        cursorCourses.getString(3),
                        cursorCourses.getInt(5),
                        cursorCourses.getInt(4),
                        cursorCourses.getInt(6)));
            } while (cursorCourses.moveToNext());
        }

        cursorCourses.close();
        return resultsArrayList;
    }
}
