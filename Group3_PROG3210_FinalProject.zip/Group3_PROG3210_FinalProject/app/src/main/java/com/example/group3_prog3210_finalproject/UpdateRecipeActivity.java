package com.example.group3_prog3210_finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.group3_prog3210_finalproject.database.DbHandler;
import com.example.group3_prog3210_finalproject.models.RecipeModel;

public class UpdateRecipeActivity extends AppCompatActivity {

    private RecipeModel recipeModel;
    private DbHandler dbHandler;

    private EditText recipeNameEdt;
    private EditText recipeIngredientsEdt;
    private EditText peopleServedEdt;
    private EditText cookingTimeEdt;
    private EditText instructionsEdt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_recipe);

        dbHandler = new DbHandler(this);

        findViewById(R.id.idBtnUpdateRecipe).setOnClickListener(this::updateRecipeSubmit);
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onStart() {
        super.onStart();

        recipeModel = dbHandler.readRecipe(getIntent().getIntExtra("id", -1));

        recipeNameEdt = findViewById(R.id.idRecipeName);
        recipeIngredientsEdt = findViewById(R.id.idRecipeIngredients);
        peopleServedEdt = findViewById(R.id.idPeopleServed);
        cookingTimeEdt = findViewById(R.id.idCookingTime);
        instructionsEdt = findViewById(R.id.idInstructions);

        recipeNameEdt.setText(recipeModel.getName());
        recipeIngredientsEdt.setText(recipeModel.getIngredientsInstructions());
        peopleServedEdt.setText(Integer.toString(recipeModel.getPeopleServed()));
        cookingTimeEdt.setText(Integer.toString(recipeModel.getCookingTime()));
        instructionsEdt.setText(recipeModel.getCookingInstructions());
    }

    private void updateRecipeSubmit(View view) {
        String recipeName = recipeNameEdt.getText().toString();
        String recipeIngredients = recipeIngredientsEdt.getText().toString();
        int peopleServed = 0;
        int cookingTime = 0;
        String instructions = instructionsEdt.getText().toString();
        boolean isFavorite = false;

        if (recipeName.isEmpty() || recipeIngredients.isEmpty() || instructions.isEmpty()) {
            Toast.makeText(this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            peopleServed = Integer.parseInt(peopleServedEdt.getText().toString());
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid number for people served.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            cookingTime = Integer.parseInt(cookingTimeEdt.getText().toString());
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid number for cooking time.", Toast.LENGTH_SHORT).show();
            return;
        }

        recipeModel.setName(recipeName);
        recipeModel.setIngredientsInstructions(recipeIngredients);
        recipeModel.setCookingInstructions(instructions);
        recipeModel.setCookingTime(cookingTime);
        recipeModel.setPeopleServed(peopleServed);
        recipeModel.setFavorite(isFavorite);

        dbHandler.updateRecipe(recipeModel);

        finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}